document.addEventListener('DOMContentLoaded', () => {
    const carrito = [];
    const carritoItems = document.getElementById('carrito-items');
    const totalElement = document.getElementById('total');
    const carritoBtn = document.getElementById('carrito-btn');
    const cerrarCarrito = document.getElementById('cerrar-carrito');

    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', () => {
            const name = button.getAttribute('data-name');
            const price = parseFloat(button.getAttribute('data-price'));
            carrito.push({ name, price });
            renderCarrito();
        });
    });

    cerrarCarrito.addEventListener('click', () => {
        document.getElementById('carrito').style.display = 'none';
    });

    carritoBtn.addEventListener('click', () => {
        document.getElementById('carrito').style.display = 'block';
    });

    function renderCarrito() {
        carritoItems.innerHTML = carrito
            .map(item => `<p>${item.name} - $${item.price.toFixed(2)}</p>`)
            .join('');
        const total = carrito.reduce((sum, item) => sum + item.price, 0);
        totalElement.textContent = `Total: $${total.toFixed(2)}`;
    }
});
