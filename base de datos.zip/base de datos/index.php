<?php
include "conexion.php";
session_start();
    

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php"); // Redirigir a login si no está autenticado
    exit();
}

$nombre_usuario = $_SESSION['nombre']; // Nombre del usuario en la sesión
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>
</head>
<body>
    <h1>Bienvenido, <?php echo $nombre_usuario; ?>!</h1>
    <p>Has iniciado sesión correctamente.</p>

    <!-- Aquí puedes agregar el contenido de la página principal -->
    <a href="logout.php">Cerrar sesión</a>
</body>

</html>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda de Refrescos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e6f7ff;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #0066cc;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 {
            margin: 0;
        }
        nav {
            display: flex;
            gap: 20px;
        }
        nav a, nav p {
            color: white;
            text-decoration: none;
            font-weight: bold;
            margin: 0;
        }
        nav p {
            margin: 0;
        }
        .product-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }
        .product {
            border: 1px solid #ccc;
            padding: 15px;
            width: 250px;
            background-color: white;
            border-radius: 8px;
            text-align: center;
        }
        .product img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }
        .product h3 {
            margin: 10px 0;
        }
        footer {
            text-align: center;
            padding: 10px;
            background-color: #0066cc;
            color: white;
        }
    </style>
</head>
<body>
    <header>
        <h1>Tienda de Refrescos</h1>
        <nav>
            <?php if (isset($_SESSION['user_name'])): ?>
                <p>Bienvenido, <?= htmlspecialchars($_SESSION['user_name']); ?> | <a href="logout.php" style="color: #ff6666;">Cerrar sesión</a></p>
            <?php else: ?>
                <a href="register.php">Registro</a>
                <a href="login.php">Iniciar Sesión</a>
            <?php endif; ?>
        </nav>
    </header>

    <section class="product-list" id="productos">
        <div class="product">
            <img src="refresco1.webp" alt="Refresco Cola">
            <h3>Refresco Cola</h3>
            <p>Precio: $15.00</p>
            <button onclick="alert('Producto agregado al carrito')">Agregar al carrito</button>
        </div>
        <div class="product">
            <img src="refresco2.webp" alt="Refresco Naranja">
            <h3>Refresco Naranja</h3>
            <p>Precio: $12.00</p>
            <button onclick="alert('Producto agregado al carrito')">Agregar al carrito</button>
        </div>
        <div class="product">
            <img src="refresco3.webp" alt="Refresco Limón">
            <h3>Refresco Limón</h3>
            <p>Precio: $10.00</p>
            <button onclick="alert('Producto agregado al carrito')">Agregar al carrito</button>
        </div>
        <div class="product">
            <img src="refrescos4.webp" alt="Refresco Manzana">
            <h3>Refresco Manzana</h3>
            <p>Precio: $14.00</p>
            <button onclick="alert('Producto agregado al carrito')">Agregar al carrito</button>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 Tienda de Refrescos. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
