<?php
$servidor = "localhost"; // Cambiar si usas otro host
$usuario = "root"; // Cambiar si tienes un usuario diferente
$password = ""; // Cambiar si tienes una contraseña
$basededatos = "fabricarefrescos"; // El nombre de tu base de datos

$conexion = new mysqli($servidor, $usuario, $password, $basededatos);

// Verifica si hay errores en la conexión
if ($conexion->connect_error) {
    die("Error al conectar con la base de datos: " . $conexion->connect_error);
}
?>
